﻿using MediaBrowser.Model.Plugins;

namespace WebSocketDemo
{
    public class PluginConfiguration : BasePluginConfiguration
    {
        public string OutputDirectory { get; set; } = "GameStreamScripts";
    }
}

